#!/bin/bash
#* ============================================================================
#* LICENSED MATERIALS - PROPERTY OF IBM
#* GaianDB
#* Copyright IBM Corp. 2007-2011
#* ALL RIGHTS RESERVED
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#* ============================================================================

[[ -z $GDBH ]] && GDBH=.
GDBL=$GDBH/lib

export CLASSPATH="$GDBL/:$GDBL/GAIANDB.jar:$GDBL/db2jcutdown.jar:$GDBL/derby.jar:$GDBL/derbyclient.jar"

export CLASSPATH="$CLASSPATH:$HOME/sqllib/java/db2jcc.jar:$HOME/sqllib/java/db2jcc_license_cu.jar"

# Use "$@" to pass in a double quoted argument as a single argument to java, e.g.
# ./queryDerby.sh -p 6414 "select * from new com.ibm.db2j.GaianTable('LT0') T"
# Note "$*" would split the "select * ..." statement into multiple arguments.

java -version
java -cp "$CLASSPATH" com.ibm.gaiandb.tools.SQLDerbyRunner "$@"
