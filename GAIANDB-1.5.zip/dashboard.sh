#!/bin/bash

[[ -z $GDBH ]] && GDBH=.
GDBL=$GDBH/lib

export CLASSPATH="$GDBL/GAIANDB.jar:$GDBL/GAIANDB-tools.jar:$GDBL/prefusetrimmed.jar:$GDBL/derby.jar:$GDBL/derbyclient.jar"

echo java -cp "$CLASSPATH" com.ibm.gaiandb.apps.dashboard.Dashboard
java -cp "$CLASSPATH" com.ibm.gaiandb.apps.dashboard.Dashboard

