#
#   File: which.py
#   Role: Windows variant of the "which" utility
#   From: Based upon Python24\Tools\scripts\which.py
# Author: Robert A. (Bob) Gibson - bgibson@us.ibm.com
#
#---------------------------------------------------------------------

import sys, os
from stat import *

#---------------------------------------------------------------------
# Simple routine to display specified message on STDERR 
#---------------------------------------------------------------------
def msg( str ):
    sys.stderr.write( str + '\n' )

def main():
    #-----------------------------------------------------------------
    # To determine which executable would be invoked, we use the $PATH
    # environment variable, as well as the valid execuatble extensions
    # (i.e., $PATHEXT).
    #-----------------------------------------------------------------
    pathlist = os.environ[ 'PATH' ].split( os.pathsep )
    pathext  = os.environ[ 'PATHEXT' ].split( os.pathsep )

    #-----------------------------------------------------------------
    # One (of the many) eccentricities of Windows is that it will
    # first try to locate the command in the current directory.  As
    # though the PATH environment variable started with '.'.  To
    # simulate this, we prepend this to the list (if it is not already
    # present).
    #-----------------------------------------------------------------
    if pathlist[ 0 ] != '.' :
        pathlist.insert( 0, '.' )

    #-----------------------------------------------------------------
    # The program that would be executed is the first one that is
    # found where the program name, with a valid extension exists in
    # one of $PATH directories.
    #-----------------------------------------------------------------
    # For each potential command specified
    #-----------------------------------------------------------------
    for prog in sys.argv[ 1: ] :
        try :
            #---------------------------------------------------------
            # Test each directory found in $PATH
            #---------------------------------------------------------
            for dir in pathlist :
                #-----------------------------------------------------
                # Build the fully qualified path including command name
                #-----------------------------------------------------
                filename = os.path.join( dir, prog )
                #-----------------------------------------------------
                # Now, for each executable extension, see if the file
                # exists.  Note that each value in PATHEXT should
                # start with the period '.' delimiter..
                #-----------------------------------------------------
                for ext in pathext :
                    program = filename + ext
                    try:
                        #---------------------------------------------
                        # See if the specified file exists.
                        #---------------------------------------------
                        st = os.stat( program )
                        #---------------------------------------------
                        # If it does, raise an exception to display
                        # the fully qualified name.
                        #---------------------------------------------
                        raise Exception( program )
                    except os.error:
                        continue
            #---------------------------------------------------------
            # Each extension has been tried in each directory...
            #---------------------------------------------------------
            msg( prog + ': not found' )
        except Exception :
            #---------------------------------------------------------
            # A match was found.  Display the fully qualified filename
            #---------------------------------------------------------
            msg( program )

#---------------------------------------------------------------------
# This is where execution begins.
# This expression is true when the script is invoked.
#---------------------------------------------------------------------
if __name__ == '__main__':
    main()
