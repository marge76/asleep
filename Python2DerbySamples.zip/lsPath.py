#!/usr/bin/python

"""lsPath - Display PATH Environment Variable in easy to read format"""

from os  import environ, path, pathsep
from sys import argv

Name  =  path.split( argv[ 0 ] )[ 1 ] 
if not Name: Name = "lsPath.py"
Usage = "Usage: python " + Name + " [Path-Environment-Variable]"

def main( EnvVar = None ):
  """lsPath()
Display Environment variable values in an easier to read format"""
  if EnvVar == None:
    EnvVar = "PATH"
  else:
    EnvVar = EnvVar.upper()
  try:
    Path = environ[ EnvVar ].split( pathsep )
    print EnvVar + "="
    for dir in Path:
      print "  " + dir
  except:
    print "Unknown ENV variable: " + EnvVar
  
if __name__ == "__main__":
  if len( argv ) == 1:
    main()
  elif len( argv ) == 2:
    main( argv[ 1 ] )
  else:
    print Usage
